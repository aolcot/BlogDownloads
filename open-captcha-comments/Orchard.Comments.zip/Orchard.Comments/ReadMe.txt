Please make sure that you take a backup of your Orchard.Comments folder first.


Then merge these files with your existing files under \modules\Orchard.Comments

