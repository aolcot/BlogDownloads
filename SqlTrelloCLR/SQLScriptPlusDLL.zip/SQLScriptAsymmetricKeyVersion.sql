--YOU MUST GENERATE AN APP KEY AND TOKEN BEFORE RUNNING THIS SCRIPT. UPDATE VALUES BELOW WITH THEM
--YOU MUST UPDATE THE FILE PATHS TO THE LOCATION OF THE DLL BEFORE RUNNING THIS SCRIPT. ENSURE YOUR SQL INSTANCE CAN ACCESS THE FILE PATH


USE master
GO
 
--Create the key by referencing the dll file
CREATE ASYMMETRIC KEY TrelloAsymmetricKey 
FROM EXECUTABLE FILE = 'c:\temp\SQLTrelloExample.dll'
GO
 
--Create a SQL login from the key that was generated
CREATE LOGIN TrelloCLRLogin 
FROM ASYMMETRIC KEY TrelloAsymmetricKey
GO
 
--Grant the required level of access to the key
GRANT EXTERNAL ACCESS ASSEMBLY TO TrelloCLRLogin
GO

--CREATE DB + TABLE
CREATE DATABASE Trello
GO
ALTER DATABASE Trello SET TRUSTWORTHY ON
GO
USE Trello
GO
CREATE TABLE [dbo].[Configuration](
    [ApplicationKey] [varchar](32) NULL,
    [Token] [varchar](64) NULL
) ON [PRIMARY]
GO

--UPDATE THE VALUES BELOW WITH YOUR APPKEY AND TOKEN
INSERT INTO Configuration (ApplicationKey, Token)
VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 
     'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
GO

--Import the assembly in the database from the dll
CREATE ASSEMBLY [SQLTrelloExample]
    AUTHORIZATION [dbo]
    FROM 'C:\temp\SQLTrelloExample.dll'
    WITH PERMISSION_SET = EXTERNAL_ACCESS;
GO
 
--Create the two procedures that reference the methods in the assembly
CREATE PROCEDURE [dbo].[CreateCard]
    @AppKey NVARCHAR (32), 
    @Token NVARCHAR (64), 
    @BoardName NVARCHAR (100), 
    @ListName NVARCHAR (100), 
    @CardName NVARCHAR (100), 
    @CardDescription NVARCHAR (4000), 
    @CardId NVARCHAR (32) OUTPUT
AS EXTERNAL NAME [SQLTrelloExample].[StoredProcedures].[CreateCard]
GO
 
CREATE PROCEDURE [dbo].[AddCommentsToCard]
    @AppKey NVARCHAR (32), 
    @Token NVARCHAR (64), 
    @CardId NVARCHAR (32), 
    @CardComments NVARCHAR (4000)
AS EXTERNAL NAME [SQLTrelloExample].[StoredProcedures].[AddCommentsToCard]
GO