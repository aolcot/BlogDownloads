--##########################################################################################
--## !! NEED TO UPDATE THE FILE PATHS TO WHERE THE DB AND FILESTREAM DATA IS TO BE STORED. !!
--##
--## !! ENSURE THAT THE SQL SERVER INSTANCE IS CONFIGURED FOR FILESTREAM !!
--##########################################################################################


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO


USE [master]
GO

CREATE DATABASE [Connect794856]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'Connect794856', FILENAME = N'E:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\Connect794856.mdf' , SIZE = 403456KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB ), 
 FILEGROUP [FileStreamGroup] CONTAINS FILESTREAM  DEFAULT 
( NAME = N'FileStreamData', FILENAME = N'E:\FileStreamData\FileStreamData' , MAXSIZE = UNLIMITED)
 LOG ON 
( NAME = N'Connect794856_log', FILENAME = N'E:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\DATA\Connect794856_log.ldf' , SIZE = 47616KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO

ALTER DATABASE [Connect794856]
SET FILESTREAM ( NON_TRANSACTED_ACCESS = FULL, DIRECTORY_NAME = N'SomeDir' )

GO
USE [Connect794856]
GO

--##########################################################################################
--##SETUP THE TEST SCHEMA
--##########################################################################################

CREATE TABLE [dbo].[Table1](
	[Id] [smallint] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](100) NULL,
	[ShortCode] [varchar](6) NULL,
	[EmailContact] [varchar](50) NULL,
	[BitCol1] [bit] NOT NULL,
	[InstallationCode] [varchar](30) NULL,
	[BitCol2] [bit] NOT NULL,
	[BitCol3] [bit] NOT NULL,
	[Hrs] [smallint] NULL,
	[BitCol4] [bit] NOT NULL,
	[InstallationCode_Collate]  AS ([InstallationCode] collate SQL_Latin1_General_CP1_CI_AS) PERSISTED,
 CONSTRAINT [PK_Table1] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Table1] ADD  DEFAULT ((1)) FOR [BitCol1]
ALTER TABLE [dbo].[Table1] ADD  DEFAULT ((1)) FOR [BitCol2]
ALTER TABLE [dbo].[Table1] ADD  DEFAULT ((1)) FOR [BitCol3]
ALTER TABLE [dbo].[Table1] ADD  DEFAULT ((1)) FOR [BitCol4]
GO
GO
CREATE TABLE dbo.Table2(
	[Id] [smallint] IDENTITY(1,1) NOT NULL,
	[xId] [smallint] NULL,
	[Name] [varchar](20) NULL,
	[zId] [smallint] NULL,
	[Active] [bit] NULL,
	[Index] [int] NULL,
	[Path] [varchar](200) NULL,
	[DateTime] [datetime] NULL,
	[Sync] [bit] NOT NULL,
	[DBName] [varchar](20) NULL,
	[NumExecutions] [int] NOT NULL,
 CONSTRAINT [PK_Table2] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE dbo.Table2 ADD  CONSTRAINT [DF_Index]  DEFAULT ((0)) FOR [Index]
ALTER TABLE dbo.Table2 ADD  CONSTRAINT [DF_Sync]  DEFAULT ((1)) FOR [Sync]
ALTER TABLE dbo.Table2 ADD  CONSTRAINT [DF_NumExecutions]  DEFAULT ((-1)) FOR [NumExecutions]
GO
CREATE TABLE [dbo].[Table3](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UploadDateTime] [datetime] NOT NULL,
	[xId] [int] NOT NULL,
	[xData] [varchar](max) NULL,
	[xKey] [varchar](50) NULL,
	[xName] [varchar](50) NULL,
	[BitCol1] [bit] NOT NULL,
	[BitCol2] [bit] NOT NULL,
	[BitCol3] [bit] NOT NULL,
 CONSTRAINT [PK_Table3] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Table3] ADD  DEFAULT (getdate()) FOR [UploadDateTime]
ALTER TABLE [dbo].[Table3] ADD  DEFAULT ((0)) FOR [BitCol1]
ALTER TABLE [dbo].[Table3] ADD  DEFAULT ((0)) FOR [BitCol2]
ALTER TABLE [dbo].[Table3] ADD  DEFAULT ((0)) FOR [BitCol3]
GO

CREATE TABLE [dbo].[Table4] AS FILETABLE ON [PRIMARY] FILESTREAM_ON [FileStreamGroup]
WITH
(
FILETABLE_DIRECTORY = N'TestFiles', FILETABLE_COLLATE_FILENAME = Latin1_General_CI_AS
)

GO

--##########################################################################################
--##INSERT SOME TEST DATA THAT MIMICS PRODUCTION
--##########################################################################################
SET IDENTITY_INSERT dbo.Table1 ON

DECLARE @Id INT = 1
WHILE @Id <= 40
BEGIN 
	INSERT INTO dbo.Table1 (Id, Name, ShortCode, EmailContact, BitCol1, InstallationCode, BitCol2, BitCol3, Hrs, BitCol4) 
	SELECT @Id, REPLICATE('a', @Id), 'AAA', 'AAAAAAA.BBBBBBBB@CCCCCCC.COM', 0, 'AAA', 1, 1, 48, 1

	SET @Id = @Id + 1
END
SET IDENTITY_INSERT dbo.Table1 OFF
GO


SET IDENTITY_INSERT [dbo].[Table2] ON 
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (693, 1, N'56275442', 35, 0, 0, N'C:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (694, 6, N'674852572', 35, 0, 0, N'C:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (695, 7, N'1929301231', 35, 0, 0, N'D:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (696, 11, N'936800069', 35, 0, 0, N'C:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (697, 12, N'331147604', 35, 0, 0, N'Z:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (698, 13, N'284900120', 35, 0, 0, N'E:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (699, 14, N'1172276519', 35, 0, 0, N'D:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (700, 23, N'1911328089', 35, 0, 0, N'D:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (701, 2, N'1125189839', 35, 0, 0, N'C:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (702, 21, N'1136243251', 35, 0, 0, N'E:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (703, 24, N'238074313', 35, 0, 0, N'C:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (704, 30, N'731227889', 35, 0, 0, N'D:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (705, 33, N'80570781', 35, 0, 0, N'C:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (706, 3, N'163163357', 35, 0, 0, N'E:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (707, 28, N'1918073445', 35, 0, 0, N'd:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (708, 19, N'649705613', 35, 0, 0, N'd:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (709, 9, N'460878417', 35, 0, 0, N'F:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (710, 26, N'234327390', 35, 0, 0, N'D:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (729, 1, N'291156466', 35, 0, 0, N'C:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (730, 12, N'29157716', 35, 0, 0, N'Z:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (731, 14, N'786400551', 35, 0, 0, N'D:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (732, 23, N'385917532', 35, 0, 0, N'D:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (733, 2, N'1125189853', 35, 0, 0, N'C:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (734, 3, N'515484893', 35, 0, 0, N'C:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (735, 19, N'767146125', 35, 0, 0, N'D:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (736, 9, N'158888529', 35, 0, 0, N'F:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (737, 26, N'234330718', 35, 0, 0, N'D:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
INSERT [dbo].[Table2] ([Id], [xId], [Name], [zId], [Active], [Index], [Path], [DateTime], [Sync], [DBName], [NumExecutions]) VALUES (738, 8, N'1535156937', 35, 0, 0, N'D:\SomeData\Fldr\Rules', NULL, 0, NULL, 0)
SET IDENTITY_INSERT [dbo].[Table2] OFF
GO

SET IDENTITY_INSERT [dbo].[Table3] ON
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470678, '2013-07-23 16:00:10', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470680, '2013-07-23 16:00:10', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470682, '2013-07-23 16:00:10', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470685, '2013-07-23 16:00:10', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470690, '2013-07-23 16:00:11', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470691, '2013-07-23 16:00:10', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470692, '2013-07-23 16:00:09', 708, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5-New.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470694, '2013-07-23 16:00:11', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470700, '2013-07-23 16:00:11', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470701, '2013-07-23 16:00:11', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470703, '2013-07-23 16:00:11', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470706, '2013-07-23 16:00:11', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470709, '2013-07-23 16:00:11', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470714, '2013-07-23 16:00:11', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470716, '2013-07-23 16:00:10', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470718, '2013-07-23 16:00:11', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470721, '2013-07-23 16:00:11', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470724, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470726, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470729, '2013-07-23 16:00:11', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470730, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470731, '2013-07-23 16:00:12', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470732, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470733, '2013-07-23 16:00:12', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470734, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470735, '2013-07-23 16:00:11', 733, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470737, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470738, '2013-07-23 16:00:12', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470739, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470742, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470744, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470748, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470751, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470754, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470757, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470759, '2013-07-23 16:00:12', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470762, '2013-07-23 16:00:13', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470968, '2013-07-23 16:00:24', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470969, '2013-07-23 16:00:24', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470971, '2013-07-23 16:00:24', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470972, '2013-07-23 16:00:24', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470973, '2013-07-23 16:00:24', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470976, '2013-07-23 16:00:24', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470977, '2013-07-23 16:00:24', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470980, '2013-07-23 16:00:25', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470982, '2013-07-23 16:00:25', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470983, '2013-07-23 16:00:25', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470986, '2013-07-23 16:00:25', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470987, '2013-07-23 16:00:25', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470988, '2013-07-23 16:00:25', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470990, '2013-07-23 16:00:25', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470992, '2013-07-23 16:00:24', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5 old.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470997, '2013-07-23 16:00:26', 695, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470999, '2013-07-23 16:00:25', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471000, '2013-07-23 16:00:27', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471001, '2013-07-23 16:00:27', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471002, '2013-07-23 16:00:27', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471003, '2013-07-23 16:00:27', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471004, '2013-07-23 16:00:27', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471005, '2013-07-23 16:00:27', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471006, '2013-07-23 16:00:27', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471007, '2013-07-23 16:00:27', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471008, '2013-07-23 16:00:28', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471009, '2013-07-23 16:00:28', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471010, '2013-07-23 16:00:28', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471011, '2013-07-23 16:00:28', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471012, '2013-07-23 16:00:27', 695, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5-old.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471014, '2013-07-23 16:00:28', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471015, '2013-07-23 16:00:28', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471016, '2013-07-23 16:00:28', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471035, '2013-07-23 16:00:28', 695, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471036, '2013-07-23 16:00:30', 695, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471037, '2013-07-23 16:00:31', 695, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471058, '2013-07-23 16:00:38', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471110, '2013-07-23 16:00:47', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471171, '2013-07-23 16:00:57', 729, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471173, '2013-07-23 16:00:59', 729, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471174, '2013-07-23 16:00:59', 729, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471175, '2013-07-23 16:00:59', 729, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471177, '2013-07-23 16:00:59', 729, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471182, '2013-07-23 16:00:14', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471184, '2013-07-23 16:00:14', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471185, '2013-07-23 16:00:15', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471186, '2013-07-23 16:00:15', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471187, '2013-07-23 16:00:15', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471188, '2013-07-23 16:00:15', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471189, '2013-07-23 16:00:15', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471190, '2013-07-23 16:00:15', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471191, '2013-07-23 16:00:15', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471192, '2013-07-23 16:00:16', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471194, '2013-07-23 16:00:16', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471195, '2013-07-23 16:00:16', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471196, '2013-07-23 16:00:16', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471197, '2013-07-23 16:00:16', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471198, '2013-07-23 16:00:16', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471200, '2013-07-23 16:00:16', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471201, '2013-07-23 16:00:16', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471202, '2013-07-23 16:00:16', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471203, '2013-07-23 16:00:17', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471204, '2013-07-23 16:00:17', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471205, '2013-07-23 16:00:17', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471206, '2013-07-23 16:00:17', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471207, '2013-07-23 16:00:17', 703, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471244, '2013-07-23 16:00:55', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471245, '2013-07-23 16:00:55', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471246, '2013-07-23 16:00:57', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471247, '2013-07-23 16:00:57', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471248, '2013-07-23 16:00:57', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471249, '2013-07-23 16:00:57', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471250, '2013-07-23 16:00:57', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471251, '2013-07-23 16:00:57', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471283, '2013-07-23 16:24:34', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471284, '2013-07-23 16:24:34', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471285, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471286, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471287, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471288, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471289, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471290, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471291, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471292, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471293, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471294, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471295, '2013-07-23 16:24:35', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471296, '2013-07-23 16:24:36', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471297, '2013-07-23 16:24:36', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471298, '2013-07-23 16:24:36', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471299, '2013-07-23 16:24:36', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471300, '2013-07-23 16:24:36', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471301, '2013-07-23 16:24:36', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471302, '2013-07-23 16:24:36', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471303, '2013-07-23 16:24:36', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471304, '2013-07-23 16:24:36', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471305, '2013-07-23 16:24:36', 738, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471334, '2013-07-23 16:32:01', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471335, '2013-07-23 16:32:01', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471336, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471337, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471338, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471339, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471340, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471341, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471342, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471343, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471344, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471345, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471346, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471347, '2013-07-23 16:32:03', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471059, '2013-07-23 16:00:38', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471060, '2013-07-23 16:00:39', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471061, '2013-07-23 16:00:39', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471062, '2013-07-23 16:00:40', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471063, '2013-07-23 16:00:40', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471064, '2013-07-23 16:00:40', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471065, '2013-07-23 16:00:40', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471066, '2013-07-23 16:00:40', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471067, '2013-07-23 16:00:40', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471068, '2013-07-23 16:00:40', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471069, '2013-07-23 16:00:40', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471070, '2013-07-23 16:00:40', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471071, '2013-07-23 16:00:40', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471072, '2013-07-23 16:00:41', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471073, '2013-07-23 16:00:41', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471074, '2013-07-23 16:00:41', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471075, '2013-07-23 16:00:41', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471076, '2013-07-23 16:00:41', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471077, '2013-07-23 16:00:41', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471078, '2013-07-23 16:00:41', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471079, '2013-07-23 16:00:41', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471081, '2013-07-23 16:00:41', 702, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471088, '2013-07-23 16:00:42', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'Copy of File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471095, '2013-07-23 16:00:43', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471096, '2013-07-23 16:00:44', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471097, '2013-07-23 16:00:45', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471098, '2013-07-23 16:00:45', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471099, '2013-07-23 16:00:45', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471100, '2013-07-23 16:00:45', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471101, '2013-07-23 16:00:45', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471102, '2013-07-23 16:00:45', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471103, '2013-07-23 16:00:45', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471104, '2013-07-23 16:00:46', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471105, '2013-07-23 16:00:46', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471106, '2013-07-23 16:00:46', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471107, '2013-07-23 16:00:46', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471108, '2013-07-23 16:00:46', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471348, '2013-07-23 16:32:04', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471349, '2013-07-23 16:32:04', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471350, '2013-07-23 16:32:04', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471351, '2013-07-23 16:32:04', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471352, '2013-07-23 16:32:04', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471353, '2013-07-23 16:32:04', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471354, '2013-07-23 16:32:04', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471355, '2013-07-23 16:32:04', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471356, '2013-07-23 16:32:05', 730, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471371, '2013-07-23 16:33:19', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5-old.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471372, '2013-07-23 16:33:20', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.old.1.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471373, '2013-07-23 16:33:21', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471374, '2013-07-23 16:33:22', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471375, '2013-07-23 16:33:22', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471376, '2013-07-23 16:33:22', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471377, '2013-07-23 16:33:22', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471378, '2013-07-23 16:33:22', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471379, '2013-07-23 16:33:23', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471380, '2013-07-23 16:33:23', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471381, '2013-07-23 16:33:23', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471382, '2013-07-23 16:33:23', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471383, '2013-07-23 16:33:23', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471384, '2013-07-23 16:33:23', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'New Text Document.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471385, '2013-07-23 16:33:24', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471386, '2013-07-23 16:33:24', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471387, '2013-07-23 16:33:24', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471388, '2013-07-23 16:33:24', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471389, '2013-07-23 16:33:24', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471390, '2013-07-23 16:33:25', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471391, '2013-07-23 16:33:25', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471392, '2013-07-23 16:33:25', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471393, '2013-07-23 16:33:25', 736, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471408, '2013-07-23 16:34:58', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471409, '2013-07-23 16:34:59', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471410, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471411, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471412, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482840, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482841, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482842, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482843, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482844, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482845, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482846, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482847, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482848, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482849, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482850, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482851, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482852, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482853, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482854, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482855, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482856, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482857, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482858, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482859, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482860, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482861, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482862, '2013-07-24 09:37:05', 734, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482872, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482873, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482874, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482875, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482876, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482877, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482878, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482879, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482880, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482881, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482882, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482883, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482884, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482885, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482886, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482887, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482888, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482889, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482890, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482891, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482892, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482893, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482894, '2013-07-24 09:42:40', 737, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482897, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482898, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482899, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482900, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482901, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482902, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482903, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482904, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482905, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482906, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482907, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482908, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482909, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482910, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482911, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482912, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482913, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482914, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482915, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482916, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482917, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482918, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482919, '2013-07-24 09:40:13', 710, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482944, '2013-07-24 09:46:18', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482945, '2013-07-24 09:46:18', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482946, '2013-07-24 09:46:18', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482947, '2013-07-24 09:46:18', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482948, '2013-07-24 09:46:18', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471252, '2013-07-23 16:00:58', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471253, '2013-07-23 16:00:58', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471254, '2013-07-23 16:00:58', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471255, '2013-07-23 16:00:58', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471256, '2013-07-23 16:00:58', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471257, '2013-07-23 16:00:58', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471258, '2013-07-23 16:00:58', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471259, '2013-07-23 16:00:59', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471260, '2013-07-23 16:00:59', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471261, '2013-07-23 16:00:59', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471262, '2013-07-23 16:00:59', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471263, '2013-07-23 16:00:59', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471264, '2013-07-23 16:00:59', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471265, '2013-07-23 16:00:59', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471266, '2013-07-23 16:00:59', 696, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470765, '2013-07-23 16:00:13', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470767, '2013-07-23 16:00:13', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470770, '2013-07-23 16:00:13', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470772, '2013-07-23 16:00:13', 709, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470788, '2013-07-23 16:00:12', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470791, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470793, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470794, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470796, '2013-07-23 16:00:14', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470797, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470801, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470803, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470806, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470808, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470809, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470810, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470813, '2013-07-23 16:00:14', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470815, '2013-07-23 16:00:15', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470816, '2013-07-23 16:00:15', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470819, '2013-07-23 16:00:15', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470823, '2013-07-23 16:00:14', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470824, '2013-07-23 16:00:15', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470827, '2013-07-23 16:00:15', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470829, '2013-07-23 16:00:15', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482761, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482762, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482763, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482764, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482765, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482766, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482767, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482768, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482769, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482770, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482771, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482772, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482773, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482774, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482775, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482776, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482777, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482778, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482779, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482780, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482781, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482782, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482783, '2013-07-24 09:30:40', 706, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471109, '2013-07-23 16:00:46', 707, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471413, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471414, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471415, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471416, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471417, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471418, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471419, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471420, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471421, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471422, '2013-07-23 16:35:01', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471423, '2013-07-23 16:35:02', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471424, '2013-07-23 16:35:02', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471425, '2013-07-23 16:35:02', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471426, '2013-07-23 16:35:02', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471427, '2013-07-23 16:35:02', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471428, '2013-07-23 16:35:02', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471429, '2013-07-23 16:35:02', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2471430, '2013-07-23 16:35:02', 732, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482949, '2013-07-24 09:46:18', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482950, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482951, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482952, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482953, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482954, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482955, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482956, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482957, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482958, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482959, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482960, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482961, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482962, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482963, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482964, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482965, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2482966, '2013-07-24 09:46:19', 704, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470412, '2013-07-23 16:00:03', 701, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470424, '2013-07-23 16:00:04', 701, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470429, '2013-07-23 16:00:04', 701, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470433, '2013-07-23 16:00:04', 701, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470480, '2013-07-23 16:00:05', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470546, '2013-07-23 16:00:05', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470551, '2013-07-23 16:00:07', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470552, '2013-07-23 16:00:07', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470558, '2013-07-23 16:00:07', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470560, '2013-07-23 16:00:07', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470563, '2013-07-23 16:00:07', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470566, '2013-07-23 16:00:07', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470570, '2013-07-23 16:00:08', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470573, '2013-07-23 16:00:08', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470579, '2013-07-23 16:00:08', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470583, '2013-07-23 16:00:08', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470585, '2013-07-23 16:00:08', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470588, '2013-07-23 16:00:08', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470592, '2013-07-23 16:00:09', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470603, '2013-07-23 16:00:09', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470606, '2013-07-23 16:00:09', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470613, '2013-07-23 16:00:09', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470615, '2013-07-23 16:00:09', 708, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'Copy of File13.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470618, '2013-07-23 16:00:09', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470624, '2013-07-23 16:00:09', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470627, '2013-07-23 16:00:07', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470631, '2013-07-23 16:00:09', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470634, '2013-07-23 16:00:09', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470637, '2013-07-23 16:00:09', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470639, '2013-07-23 16:00:09', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470642, '2013-07-23 16:00:10', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470643, '2013-07-23 16:00:09', 697, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470646, '2013-07-23 16:00:10', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470653, '2013-07-23 16:00:10', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470659, '2013-07-23 16:00:10', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470663, '2013-07-23 16:00:10', 700, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470234, '2013-07-23 15:55:06', 693, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470235, '2013-07-23 15:55:07', 693, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470236, '2013-07-23 15:55:07', 693, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470237, '2013-07-23 15:55:07', 693, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470238, '2013-07-23 15:55:07', 693, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470268, '2013-07-23 16:00:14', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470269, '2013-07-23 16:00:15', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470270, '2013-07-23 16:00:16', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5_backup090312.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470271, '2013-07-23 16:00:18', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470272, '2013-07-23 16:00:18', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File9.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470273, '2013-07-23 16:00:18', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470274, '2013-07-23 16:00:18', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470275, '2013-07-23 16:00:18', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470276, '2013-07-23 16:00:18', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470277, '2013-07-23 16:00:18', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470278, '2013-07-23 16:00:18', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470279, '2013-07-23 16:00:18', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470280, '2013-07-23 16:00:19', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470281, '2013-07-23 16:00:19', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470282, '2013-07-23 16:00:19', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470283, '2013-07-23 16:00:19', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470284, '2013-07-23 16:00:19', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470285, '2013-07-23 16:00:19', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470286, '2013-07-23 16:00:19', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470287, '2013-07-23 16:00:20', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470288, '2013-07-23 16:00:20', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470289, '2013-07-23 16:00:20', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470290, '2013-07-23 16:00:20', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470291, '2013-07-23 16:00:20', 705, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470358, '2013-07-23 16:00:03', 701, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File4.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470831, '2013-07-23 16:00:15', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470834, '2013-07-23 16:00:15', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470835, '2013-07-23 16:00:16', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470837, '2013-07-23 16:00:16', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470839, '2013-07-23 16:00:16', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470840, '2013-07-23 16:00:16', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File1.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470841, '2013-07-23 16:00:16', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470843, '2013-07-23 16:00:16', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470844, '2013-07-23 16:00:16', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File2.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470845, '2013-07-23 16:00:16', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470846, '2013-07-23 16:00:16', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470847, '2013-07-23 16:00:16', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470848, '2013-07-23 16:00:16', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470849, '2013-07-23 16:00:16', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File3.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470850, '2013-07-23 16:00:16', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470853, '2013-07-23 16:00:16', 699, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470858, '2013-07-23 16:00:16', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File6.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470864, '2013-07-23 16:00:17', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470869, '2013-07-23 16:00:17', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File7.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470872, '2013-07-23 16:00:17', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470876, '2013-07-23 16:00:17', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File8.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470879, '2013-07-23 16:00:17', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470882, '2013-07-23 16:00:17', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File11.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470887, '2013-07-23 16:00:17', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470891, '2013-07-23 16:00:17', 698, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File13.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470937, '2013-07-23 16:00:20', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'Copy of File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470954, '2013-07-23 16:00:22', 735, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File14.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470961, '2013-07-23 16:00:22', 694, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'Copy of File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470963, '2013-07-23 16:00:21', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File5.xml', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470964, '2013-07-23 16:00:23', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.txt', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470965, '2013-07-23 16:00:24', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File10.tx_', 1, 0, 0)
INSERT INTO [dbo].[Table3] (Id, UploadDateTime, xId, xData, xKey, xName, BitCol1, BitCol2, BitCol3) VALUES (2470967, '2013-07-23 16:00:24', 731, REPLICATE(CAST('A' AS VARCHAR(MAX)), 800000), 'AABBCCDD', 'File12.txt', 1, 0, 0)
SET IDENTITY_INSERT [dbo].[Table3] OFF
GO

INSERT INTO [dbo].[Table4] (name, is_directory)
SELECT name, 1 FROM [dbo].[Table2]
GO


--##########################################################################################
--##FORCE PARALLEL PLAN AND RUN QUERY. THIS WILL RAISE THE EXCEPTION
--##########################################################################################

DBCC FREEPROCCACHE
DBCC SETCPUWEIGHT(1000)
GO
INSERT INTO [dbo].[Table4] (name, file_stream, path_locator)
SELECT t3.xName, CAST(t3.xData AS VARBINARY(MAX)),
path_locator.ToString() +  convert(varchar(20), convert(bigint, substring(convert(binary(16), newid()), 1, 6))) + '.' 
                           +  convert(varchar(20), convert(bigint, substring(convert(binary(16), newid()), 7, 6))) + '.' 
                           +  convert(varchar(20), convert(bigint, substring(convert(binary(16), newid()), 13, 4))) + '/'
FROM [dbo].[Table1] t1
INNER JOIN [dbo].[Table2] t2 ON t1.Id = t2.xId 
INNER JOIN [dbo].[Table3] t3 ON t2.Id = t3.xId
INNER JOIN [dbo].[Table4] t4 ON t4.name = t2.Name
WHERE t2.zId = 35
GO



--##########################################################################################
--##TIDY UP (NEED TO RUN MANUALLY OR DROP DB)
--##########################################################################################

DBCC SETCPUWEIGHT(1)
DBCC FREEPROCCACHE
GO

DROP TABLE [dbo].[Table1]
DROP TABLE [dbo].[Table2]
DROP TABLE [dbo].[Table3]
DROP TABLE [dbo].[Table4]
GO

